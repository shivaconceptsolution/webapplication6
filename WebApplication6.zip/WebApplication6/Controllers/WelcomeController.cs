﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.Controllers
{
    public class WelcomeController : Controller
    {
        [ActionName("Index")]
        public IActionResult Hello()
        {
            return View("hello");

        }
        public IActionResult Hello2()
        {
            return View();
        }
    }
}