﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using WebApplication6.Models;
namespace WebApplication6.Controllers
{
    public class GuestController : Controller
    {
        int a, b, c;
        // GET: Guest
        public ActionResult Index()
        {
           // var routeValue = new RouteValueDictionary
 //(new { action = "Index7", controller = "Guest" });
           return RedirectToRoute("third");
           // return View();
        }
        public ActionResult Aboutus()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult Contactus()
        {
            return View();
        }
        public ActionResult Gallery()
        {
            return View();
        }

        public ActionResult Login()
        {

            return View();
        }

        [HttpPost]

        public ActionResult Login(Reg r)
        {
            if(r.username.Equals("user1") && r.password.Equals("pass1"))
            {
                TempData["uid"] = r.username;
                TempData.Keep();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Data = "Invalid Login";
                return View();
            }


        }

        /*  public IActionResult ViewMethod1()
          {

              return View();
          }

          [HttpPost]
          public IActionResult Addition(IFormCollection obj)
          {
              ViewBag.data =Convert.ToInt32(obj["num1"].ToString()) + Convert.ToInt32(obj["num2"].ToString());

              return View("ViewMethod1");
          }
          public IActionResult ViewMethod1()
          {

              return View();
          }

          [HttpPost]
          public IActionResult Addition(String num1,String num2)
          {
              ViewBag.data = Convert.ToInt32(num1) + Convert.ToInt32(num2);

              return View("ViewMethod1");
          }*/

        public ActionResult ViewMethod1()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Addition()
        {
            ViewBag.data = Convert.ToInt32(Request.Form["num1"]) + Convert.ToInt32(Request.Form["num2"]);

            return View("ViewMethod1");
        }


        public ContentResult ViewMethod2()
        {
            return Content("Welcome in MVC");
        }

        public PartialViewResult ViewMethod3()
        {
            ViewMethod4();
            return PartialView("ViewMethod3");

        }
        public EmptyResult ViewMethod4()
        {
            a = 100; b = 200;
            c = a + b;
            ViewBag.data = c;
            return new EmptyResult();
        }

        public FileResult ViewMethod5()
        {
           
            return File("data.html","text/html");

        }
        public JsonResult ViewMethod6()
        {

            return Json(new { rno=1001 , name="xyz" });

        }
        public IActionResult Index7()
        {
             return new JavaScriptResult("alert('welcome in scs')");
           // return new JavaScriptResult("window.location.href = 'https://www.aspsnippets.com/'");
        }

        public ActionResult Index8()
        {
            // return Redirect("https://eroomrent.in");
             return Redirect("/Home/Index");
        }

        

    }
    public class JavaScriptResult : ContentResult
    {
        public JavaScriptResult(string script)
        {
            this.Content = script;
            this.ContentType = "application/javascript";
        }
    }
}