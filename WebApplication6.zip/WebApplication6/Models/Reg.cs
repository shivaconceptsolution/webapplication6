﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Models
{
    public class Reg
    {
        public String username { get; set; }
        public String password { get; set; }
    }
}
